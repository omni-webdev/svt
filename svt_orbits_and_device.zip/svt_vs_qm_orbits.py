# Re-import libraries after state reset
import os
import matplotlib.pyplot as plt
import numpy as np

# Output directory
output_dir = os.path.join(os.getcwd(), "svt_qm_mercury_outputs")
os.makedirs(output_dir, exist_ok=True)

# Orbital radii estimates for Hg (Quantum, Å) — simplified
qm_radii = {
    '1s': 0.25, '2s': 0.5, '2p': 0.55,
    '3s': 0.9, '3p': 1.0, '3d': 1.2,
    '4s': 1.5, '4p': 1.6, '4d': 1.8, '4f': 2.0,
    '5s': 2.2, '5p': 2.3, '5d': 2.4,
    '6s': 2.6
}

# Simulated SVT field radius predictions (Å) — just slightly modulated QM for now
def svt_radius(qm_r, orbital):
    if 's' in orbital:
        return qm_r * 1.05
    elif 'p' in orbital:
        return qm_r * 1.08
    elif 'd' in orbital:
        return qm_r * 1.10
    elif 'f' in orbital:
        return qm_r * 1.15
    return qm_r

orbitals = list(qm_radii.keys())
x = np.arange(len(orbitals))

qm_vals = [qm_radii[o] for o in orbitals]
svt_vals = [svt_radius(qm_radii[o], o) for o in orbitals]

# Plot comparison
plt.figure(figsize=(12, 6))
plt.plot(x, qm_vals, 'o-', label='Quantum Mechanical Radii')
plt.plot(x, svt_vals, 'x--', label='SVT Predicted Confinement')
plt.xticks(x, orbitals, rotation=45)
plt.ylabel("Orbital Radius (Å)")
plt.title("Mercury Orbital Radius: SVT vs Quantum Mechanics")
plt.grid(True)
plt.legend()
output_path = os.path.join(output_dir, "svt_vs_qm_mercury.png")
plt.tight_layout()
plt.savefig(output_path)
plt.close()
